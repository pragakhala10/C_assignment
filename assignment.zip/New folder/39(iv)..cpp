#include<stdio.h>
#include<conio.h>
int main()
{
	int x=10;
	while(1)
	{
		printf("\nx=%d",x++);
	}
	getch();
	return 0;
}
