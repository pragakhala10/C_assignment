#include<stdio.h>
#include<conio.h>
int main()
{
	int a=10,b;
	for(b=1;b<=10;b++);
	{
		a++;
	}
	printf("\na=%d\tb=%d",a,b);
	getch();
	return 0;
}
