// use of conditional operator

#include<stdio.h>
int main()
{
	int x=2, z=4, y;
	printf("y=%d", x>z ? x:z);

	return 0;
}
