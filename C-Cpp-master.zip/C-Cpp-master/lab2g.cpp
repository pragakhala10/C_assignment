// Sizeof datatype

#include<stdio.h>
#include<conio.h>
int main()
{
	int i;
	printf("size of int is : %d\n",sizeof(int));
	printf("size of char is : %d\n",sizeof(char));
	printf("size of float is : %d\n",sizeof(float));
	printf("size of double is : %d\n",sizeof(double));
	printf("size of long double is : %d",sizeof(long double));
	getch();
	return 0;
}
