// Multiply two numbers

#include<stdio.h>
#include<conio.h>
int main()
{
	int a,b,product;
	printf("Enter two numbers:");
	scanf("%d%d",&a,&b);
	product = a*b;
	printf("The product is %d.",product);
	getch();
	return 0;
}
