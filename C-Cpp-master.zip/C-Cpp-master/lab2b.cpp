// Display int and float

#include<stdio.h>
#include<conio.h>
int main()
{
	int a=10,b=15;
	float c=12.6;
	printf("The numbers are %d, %d and %.1f.",a,b,c);
	getch();
	return 0;
}
