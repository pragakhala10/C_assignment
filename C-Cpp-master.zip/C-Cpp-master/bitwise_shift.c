// Use of bitwise shift operator

#include<stdio.h>
int main()
{
	int x=2, z=4;
	printf("y=%d", x>>2+z<<1);

	return 0;
}
