// Code testing station

#include <stdio.h>
#include <conio.h>
int main()
{
	int x = 5,y,z=3, a[10];

   printf("address of x = %p\n", &x);
   printf("address of y = %p\n", &y);
   printf("address of z = %p\n", &z);
   printf("address of a = %p\n", &a);
     
 
   getch();
   return 0;
}
