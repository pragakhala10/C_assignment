#include<stdio.h>
#include<conio.h>
int main()
{
	int i;
	
	for(i=0;i<=255;i++)
	{
		printf("The ASCII value of %c is %i\n",i,i);
	}
	return 0;
}
